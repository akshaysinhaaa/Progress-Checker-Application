import 'package:flutter/material.dart';

const Color backgroundColor2 = Color.fromARGB(255, 0, 0, 0);
const Color backgroundColorLight = Color(0xFFF2F6FF);
const Color backgroundColorDark = Color.fromARGB(255, 0, 0, 0);
const Color shadowColorLight = Color(0xFF4A5367);
const Color shadowColorDark = Colors.black;
