package com.example.progress_checker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
